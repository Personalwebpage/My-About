<?php
/**
 * @package New ticker
 * @version 1.0
 */
/*
Plugin Name: List updown ticker
Plugin URI: 
Description: This is updown ticker

Author: Md Alamgir
Version: 1.0
Author URI: example.com
*/
function ticker_js_add(){ 

  wp_enqueue_script('jquery');
  
}
add_action('init', 'ticker_js_add');


function ticker_add(){ 

  wp_enqueue_script( 'ticker_js', plugins_url( '/js/jquery.ticker.js', __FILE__ ), array('jquery'), 1.2, false);
  wp_enqueue_style( 'ticker_css', plugins_url( '/css/style.css', __FILE__ ));
  
}
add_action('init', 'ticker_add');


	
function ticker_html_markup($atts){
	extract( shortcode_atts(array(
	 'id'=> 'tickerid',
	 'category'=> '',
	 'count'=> '5',
	 'category_slug'=> 'category_ID',
	 'speed'=> '3000',
	 'color'=> '#000',
	),
	$atts, 'projects'
	) );
	$q = new WP_Query(
	array('post_per_page' => $count, 'post_type' => 'post', $category_slug => $category));
	
	$list = '<script type="text/javascript"> jQuery(document).ready(function(){

	jQuery("#ticker_news'.$id.'").ticker({
		itemSpeed: '.$speed.',
	});

});
</script>
<div id="ticker_news'.$id.'" class="ticker">
  <strong style="background-color:'.$color.'">Leatest News:</strong>
  <ul>';
  
    while($q->have_posts()) : $q->the_post();
	 $idd = get_the_ID();
	 $list .= '<li><a href="<?php the_permalink(); ?>">'.get_the_title().'</a></li>';
	 
     endwhile;
	 $list.= '</ul>
</div>';
   wp_reset_query();
	return $list;
}
add_shortcode('tickerupdown', 'ticker_html_markup');


/*

// for setting option code

add_action( 'admin_menu', 'my_plugin_menu' );

function my_plugin_menu() {
	add_options_page( 
		'My Options',
		'Md Alamgir',
		'manage_options',
		'my-plugin.php',
		'my_plugin_page'
	);
}


function my_plugin_page(){
	echo"Md Alamgir Here";
	?> <h1> He say I love you</h1>  <?php
}

// for dashbord menu 

add_action( 'admin_menu', 'my_plugin_menus' );

function my_plugin_menus() {
	add_menu_page( 
		'My Options',
		'Md Alamgir',
		'manage_options',
		'my-plugin.php',
		'my_plugin_pages',
		 plugins_url( '/img/icon.png', __FILE__ ),
        30
	);
}


function my_plugin_pages(){
	echo"Md Alamgir Here";
	?> <h1> He say I love you</h1>  <?php
}


*/




?>